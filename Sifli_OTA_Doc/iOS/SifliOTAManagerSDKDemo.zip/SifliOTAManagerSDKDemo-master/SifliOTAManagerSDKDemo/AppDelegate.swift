import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        self.window = UIWindow.init(frame: UIScreen.main.bounds)
        let manVC = MainVC.init(nibName: "MainVC", bundle: Bundle.main)
        self.window?.rootViewController = manVC
        self.window?.makeKeyAndVisible()
        
        return true
    }

}

