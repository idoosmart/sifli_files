import UIKit
import SifliOTAManagerSDK
import CoreBluetooth

class MainVC: UIViewController, SFOTAManagerDelegate {
    
    let manager = SFOTAManager.share

    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.delegate = self
    }

    @IBAction func clickStartNandButton(_ sender: Any) {
        if manager.isBusy {
            NSLog("Manager正忙")
            return
        }
        
        /// 测试时请在Bundle中替换成与设备匹配的资源文件。
        
        guard let zipPath = Bundle.main.url(forResource: "1.0.3_to_1.0.2_diff", withExtension: "zip") else {
            NSLog("没有Resource Zip文件")
            return
        }
        guard let ctrlPath = Bundle.main.url(forResource: "nand_ctrl", withExtension: "bin") else {
            NSLog("没有Ctrl文件")
            return
        }
        guard let hcpuPath = Bundle.main.url(forResource: "nand_hcpu", withExtension: "bin") else {
            NSLog("没有Image文件")
            return
        }
        
        /// 替换成实际的目标设备的identifier。
        /// 该值可通过创建CBCentralManager开启搜索，获取到CBPeripheral对象后访问其identifier.uuidString属性而获得
        let identifier = "9D4E1368-DAC9-C5E7-AE21-6B0D325539E6"
        
        // 指定Image文件的本地地址和类型
        let hcpuImageFile = SFNandImageFileInfo.init(path: hcpuPath, imageID: .HCPU)
        
        /// 启动Nand升级
        manager.startOTANand(targetDeviceIdentifier: identifier, resourceZipPath: zipPath, controlImageFilePath: ctrlPath, imageFileInfos: [hcpuImageFile], tryResume: false)
        
    }
    
    @IBAction func clickStartNorV2Button(_ sender: Any) {
        if manager.isBusy {
            NSLog("Manager正忙")
            return
        }
        
        /// 测试时请在Bundle中替换成与设备匹配的资源文件。
        
        guard let ctrlPath = Bundle.main.url(forResource: "norv2_ctrl", withExtension: "bin") else {
            NSLog("没有Ctrl文件")
            return
        }
        guard let hcpuPath = Bundle.main.url(forResource: "norv2_hcpu", withExtension: "bin") else {
            NSLog("没有Image文件")
            return
        }
        
        /// 替换成实际的目标设备的identifier。
        /// 该值可通过创建CBCentralManager开启搜索，获取到CBPeripheral对象后访问其identifier.uuidString属性而获得
        let identifier = "9D4E1368-DAC9-C5E7-AE21-6B0D325539E6"
        let imageFileInfo = SFNorImageFileInfo(path: hcpuPath, imageID: .HCPU)
        
        /// 启动NorV2升级
        manager.startOTANorV2(targetDeviceIdentifier: identifier, controlImageFilePath: ctrlPath, imageFileInfos: [imageFileInfo], tryResume: true)
    }
    
    @IBAction func clickStartNorV1Button(_ sender: Any) {
        
        if manager.isBusy {
            NSLog("Manager正忙")
            return
        }
        
        /// 测试时请在Bundle中替换成与设备匹配的资源文件。
        
        guard let ctrlPath = Bundle.main.url(forResource: "norv1_ctrl", withExtension: "bin") else {
            NSLog("没有Ctrl文件")
            return
        }
        guard let hcpuPath = Bundle.main.url(forResource: "norv1_hcpu", withExtension: "bin") else {
            NSLog("没有Image文件")
            return
        }
        
        /// 替换成实际的目标设备的identifier。
        /// 该值可通过创建CBCentralManager开启搜索，获取到CBPeripheral对象后访问其identifier.uuidString属性而获得
        let identifier = "9D4E1368-DAC9-C5E7-AE21-6B0D325539E6"
        let imageFileInfo = SFNorImageFileInfo(path: hcpuPath, imageID: .HCPU)
        
        
        /// 启动NorV1升级
        manager.startOTANorV1(targetDeviceIdentifier: identifier, ctrlFilePath: ctrlPath, imageFileInfos: [imageFileInfo], triggerMode: .force)
    }
    
    @IBAction func clickStopButton(_ sender: Any) {
        manager.stop()
    }
    
    
    
    /// SDK回调-蓝牙状态改变
    /// - Parameters:
    ///   - manager: SFOTAManager对象
    ///   - state: 当前蓝牙状态
    func otaManager(manager: SFOTAManager, updateBleState state: CBManagerState) {
        /// state为poweredOn时，才能使用SFOTAManager.startOTAXXX开启升级。否则会失败。
        /// SDK内部的蓝牙状态还可以通过SFOTAManager.bleState主动获取。
        /// 一般情况下调用SFOTAManager.share后，到state就会变为powerOn状态之间有几十毫秒的间隔
        /// 因此如果第一次调用SFOTAManager.share后，立即调用startOTAXXXX一定会启动失败
        /// 处理方式有两种：1、监听该回调函数，state为powerOn后再启动；2、在AppDelegate中，APP启动函数中调用一次SFOTAManager.share，那么当用户操作升级时，蓝牙状态就已经准备好了。
        NSLog("蓝牙状态改变: \(state)")
    }
    
    
    /// SDK回调函数-进度
    /// - Parameters:
    ///   - manager: SFOTAManager对象
    ///   - stage: 当前所在的升级阶段。Nor升级只有一个阶段，Nand升级分为两个阶段
    ///   - totalBytes: 在当前阶段需要发送的文件总字节数量
    ///   - completedBytes: 在当前阶段已经完成发送的字节数
    func otaManager(manager: SFOTAManager, stage: SFOTAProgressStage, totalBytes: Int, completedBytes: Int) {
        NSLog("升级进度：stage=\(stage), \(completedBytes)/\(totalBytes)")
    }
    
    
    /// SDK回调函数-升级结束
    /// - Parameters:
    ///   - manager: SFOTAManager对象
    ///   - error: 错误信息，如果nil表示升级成功。不为nil表示升级失败
    func otaManager(manager: SFOTAManager, complete error: SFOTAError?) {
        if let err = error {
            NSLog("升级失败：\(err.errorDes)")
        }else{
            NSLog("升级成功")
        }
    }

}
