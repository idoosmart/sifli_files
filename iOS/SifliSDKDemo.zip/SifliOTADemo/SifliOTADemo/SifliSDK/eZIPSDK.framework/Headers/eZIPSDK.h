//
//  eZIPSDK.h
//  eZIPSDK
//
//  Created by Sifli on 2021/11/12.
//

#import <Foundation/Foundation.h>

//! Project version number for eZIPSDK.
FOUNDATION_EXPORT double eZIPSDKVersionNumber;

//! Project version string for eZIPSDK.
FOUNDATION_EXPORT const unsigned char eZIPSDKVersionString[];

#import "ImageConvertor.h"
// In this header, you should import all the public headers of your framework using statements like #import <eZIPSDK/PublicHeader.h>


