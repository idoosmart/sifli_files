//
//  IDOScManager.m
//  SifliOTADemo
//
//  Created by cyf on 2024/12/31.
//

#import "IDOScManager.h"
#include "ido_app_custom_dial_make.h"

@implementation IDOScManager


/**
 * 制作思澈表盘文件
 * filePath:  素材路径,
 * @return 制作成功后文件的路径，若失败，则返回为nil；
 */
+ (int)getMakeSiFliWatchDialWithFilePath:(NSString *)filePath {
    
    NSLog(@"making sc watch dial zip");
    
    NSURL * url = [NSURL URLWithString:filePath];
    if (!url) {
        NSLog(@"making sc watch dial zip error: url == nil");
        return -1;
    }else {
       
        int32_t errCode =  ido_app_custom_dial_make([filePath UTF8String]);
        NSLog(@"making sc watch dial errCode: %d",errCode);
        return errCode;
    }
}
@end
