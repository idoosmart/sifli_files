//
//  AppDelegate.h
//  SifliOTADemo
//
//  Created by cyf on 2024/12/26.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

