//
//  IDOSifliOtaManager.m
//  SifliOTADemo
//
//  Created by cyf on 2024/12/26.
//

#import "IDOSifliOtaManager.h"
#import <SifliOTAManagerSDK/SifliOTAManagerSDK.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "sys/utsname.h"

@interface IDOSifliOtaManager ()<SFOTAManagerDelegate>

//设备UUID
@property (nonatomic,strong) NSString *deviceUUID;

//当前升级进度
@property (nonatomic,assign) NSInteger currentProgress;

//是否处于升级中
@property (nonatomic,assign) BOOL updateOtaing;

@end

@implementation IDOSifliOtaManager

static IDOSifliOtaManager *_mgr = nil;

+ (IDOSifliOtaManager *)shareInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _mgr = [[IDOSifliOtaManager alloc] init];
    });
    return _mgr;
}

- (instancetype)init{
    if(self = [super init]){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelSifliDelegate) name:@"kCancelSifliOtaDelegateNotification" object:nil];
    }
    return self;
}

+ (instancetype)alloc{
    if (_mgr) {
        NSException *exception = [NSException exceptionWithName:@"重复创建IDOSifliOtaManager单例对象异常" reason:@"请使用[IDOSifliOtaManager shareInstance]的单例方法." userInfo:nil];
        [exception raise];
    }
    return [super alloc];
}


- (void)setConfigDelegate:(BOOL)configDelegate{
    _configDelegate = configDelegate;
    if(_configDelegate){
        [SFOTAManager share].delegate = self;
    }else{
        [SFOTAManager share].delegate = nil;
    }
}

- (void)startOTAWithFiles:(NSArray *)files deviceUUID:(NSString *)deviceUUID {
    if(![files isKindOfClass:[NSArray class]] || files.count == 0 || deviceUUID.length < 10){
        NSString *desc = [NSString stringWithFormat:@"传输过来的文件为空 或者 deviceUUID ： %@",deviceUUID];
        [self saveLog:desc];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kSifliOTAResultNotification" object:@{
            @"result" : @"NO",
            @"errorCode" : @(-1)
        }];
        return;
    }
    
    self.updateOtaing = YES;
    self.currentProgress = 0;
    self.deviceUUID = deviceUUID;
    
    NSString *desc1 = [NSString stringWithFormat:@"开始进行Sifli升级 files:%@ \n self.deviceUUID:%@",files,self.deviceUUID];
    [self saveLog:desc1];
    
    if(![SFOTAManager share].delegate){
        [SFOTAManager share].delegate = self;
    }
    
//#ifdef DEBUG
    // 打开思澈OTA 升级日志
    [SFOTALogManager share].logEnable = YES;
//#endif
    
   
    NSURL *ctrlURL = nil;
    NSArray *imagefiles = [self platformFiles:files ctrlURL:&ctrlURL];
    [[SFOTAManager share] startOTANorV2WithTargetDeviceIdentifier:self.deviceUUID
                                                 controlImageFilePath:ctrlURL
                                                       imageFileInfos:imagefiles
                                                            tryResume:YES
                                                    responseFrequency:[self isPhone8AndBelow] ? 5 : 20];
    
    
    NSString *desc = [NSString stringWithFormat:@"开始进行Sifli升级ctrlURL:%@ \n files:%@ \n self.deviceUUID:%@",ctrlURL,files,self.deviceUUID];
    [self saveLog:desc];
}

// 获取手机型号
- (BOOL)isPhone8AndBelow{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];


    // iPhone
    if ([platform isEqualToString:@"iPhone1,1"]) return YES;//@"iPhone 2G"
    if ([platform isEqualToString:@"iPhone1,2"]) return YES;//@"iPhone 3G"
    if ([platform isEqualToString:@"iPhone2,1"]) return YES;//@"iPhone 3GS"
    if ([platform isEqualToString:@"iPhone3,1"]) return YES;// @"iPhone 4"
    if ([platform isEqualToString:@"iPhone3,2"]) return YES;//@"iPhone 4"
    if ([platform isEqualToString:@"iPhone3,3"]) return YES;//@"iPhone 4"
    if ([platform isEqualToString:@"iPhone4,1"]) return YES;//@"iPhone 4S"
    if ([platform isEqualToString:@"iPhone5,1"]) return YES;//@"iPhone 5"
    if ([platform isEqualToString:@"iPhone5,2"]) return YES;//@"iPhone 5"
    if ([platform isEqualToString:@"iPhone5,3"]) return YES;//@"iPhone 5c"
    if ([platform isEqualToString:@"iPhone5,4"]) return YES;//@"iPhone 5c"
    if ([platform isEqualToString:@"iPhone6,1"]) return YES;//@"iPhone 5s"
    if ([platform isEqualToString:@"iPhone6,2"]) return YES;//@"iPhone 5s"
    if ([platform isEqualToString:@"iPhone7,1"]) return YES;//@"iPhone 6 Plus"
    if ([platform isEqualToString:@"iPhone7,2"]) return YES;//@"iPhone 6"
    if ([platform isEqualToString:@"iPhone8,1"]) return YES;//@"iPhone 6s"
    if ([platform isEqualToString:@"iPhone8,2"]) return YES;//@"iPhone 6s Plus"
    if ([platform isEqualToString:@"iPhone8,4"]) return YES;//@"iPhone SE"
    if ([platform isEqualToString:@"iPhone9,1"]) return YES;//@"iPhone 7"
    if ([platform isEqualToString:@"iPhone9,2"]) return YES;//@"iPhone 7 Plus"
    if ([platform isEqualToString:@"iPhone10,1"]) return YES;//@"iPhone 8"
    if ([platform isEqualToString:@"iPhone10,4"]) return YES;//@"iPhone 8"
    if ([platform isEqualToString:@"iPhone10,2"]) return YES;//@"iPhone 8 Plus"
    if ([platform isEqualToString:@"iPhone10,5"]) return YES;//@"iPhone 8 Plus"
    return NO;
}

- (NSArray *)platformFiles:(NSArray *)files ctrlURL:(NSURL **)ctrlURL{
    NSMutableArray *imagefiles = [NSMutableArray array];
    NSURL *cUrl = nil;
    for (NSString *file in files) {
        NSURL *url = [NSURL fileURLWithPath:file];
        if(!url){
            continue;
        }
        
        if([file hasSuffix:@".zip"]){
            continue;
        }else if ([file hasSuffix:@"ctrl_packet.bin"]){
            cUrl = url;
        }else if ([file hasSuffix:@"outER_IROM1.bin"] || [file hasSuffix:@"ER_IROM1.bin"]){
            SFNorImageFileInfo *info = [[SFNorImageFileInfo alloc]initWithPath:url imageID:NorImageIDHCPU];
            [imagefiles addObject:info];
        }
        else if ([file hasSuffix:@"outroot.bin"]){
            SFNorImageFileInfo *info = [[SFNorImageFileInfo alloc]initWithPath:url imageID:NorImageIDEX];
            [imagefiles addObject:info];
        }else if ([file hasSuffix:@"outER_IROM2.bin"]){
            SFNorImageFileInfo *info = [[SFNorImageFileInfo alloc]initWithPath:url imageID:NorImageIDRES];
            [imagefiles addObject:info];
        }else if ([file hasSuffix:@"outER_IROM3.bin"]){
            SFNorImageFileInfo *info = [[SFNorImageFileInfo alloc]initWithPath:url imageID:NorImageIDFONT_OR_MAX];
            [imagefiles addObject:info];
        }else if ([file hasSuffix:@"ota_manager.bin"]){
            SFNorImageFileInfo *info = [[SFNorImageFileInfo alloc]initWithPath:url imageID:NorImageIDOTA_MANAGER];
            [imagefiles addObject:info];
        }
    }
    *ctrlURL = cUrl;
    return imagefiles;
}


#pragma mark - SFOTAManagerDelegate
/// 蓝牙状态改变回调。当state为poweredOn时才能启动升级，否则会启动失败。
/// state还可以通过manager的bleState属性来主动获取。
- (void)otaManagerWithManager:(SFOTAManager *)manager updateBleState:(enum BleCoreManagerState)state{
    NSString *desc = [NSString stringWithFormat:@"OTA --- otaManagerWithManager updateBleState:%ld self.updateOtaing:%d",state,self.updateOtaing];
    [self saveLog:desc];
    
    if(self.updateOtaing){
        self.updateOtaing = NO;
        if(state != CBManagerStatePoweredOn){
            [self resultWithCode:-1 result:NO];
        }
    }
}

/// 进度回调
/// \param manager 管理器
/// \param stage 当前所处的发送阶段
/// \param totalBytes 当前阶段总字节数
/// \param completedBytes 当前阶段已完成字节数
- (void)otaManagerWithManager:(SFOTAManager * _Nonnull)manager stage:(enum SFOTAProgressStage)stage totalBytes:(NSInteger)totalBytes completedBytes:(NSInteger)completedBytes{
    
    if(self.updateOtaing){
        CGFloat progress = totalBytes > 0 ? (completedBytes * 1.0 /  totalBytes) : 0;
        
        NSInteger proLovalue = progress * 100;
        if(completedBytes != self.currentProgress){
            if (proLovalue % 10 == 0  && progress > 0 && self.currentProgress != proLovalue){
                self.currentProgress = proLovalue;
                NSString *desc = [NSString stringWithFormat:@"OTA --- otaManagerWithManager stage:%ld  totalBytes:%ld  completedBytes:%ld  progress：%lf",stage,totalBytes,completedBytes,progress];
                [self saveLog:desc];
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:@"kSifliOTAProgressNotification" object:@(progress)];
            });
        }
    }
}

/// OTA流程结束
/// \param manager 管理器
/// \param error nil-表示成功，否则表示失败
- (void)otaManagerWithManager:(SFOTAManager * _Nonnull)manager complete:(SFOTAError * _Nullable)error{
    if(self.updateOtaing){
        self.updateOtaing = NO;
        NSString *desc = [NSString stringWithFormat:@"OTA ----  Sifli otaManagerWithManager complete errorType:%ld  errorDes:%@",error.errorType,error.errorDes];
        [self saveLog:desc];
        [self resultWithCode:error.errorType result:error ? NO : YES];
    }
}

- (void)resultWithCode:(NSInteger)errorCode result:(BOOL)result{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kSifliOTAResultNotification" object:@{
            @"result" : @(result),
            @"errorCode" : @(errorCode)
        }];
    });
}

#pragma mark - 通知
- (void)cancelSifliDelegate{
    [SFOTAManager share].delegate = nil;
}

- (void)saveLog:(NSString *)log{
  //日志存储
}
@end
