//
//  IDOSifliOtaManager.h
//  SifliOTADemo
//
//  Created by cyf on 2024/12/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDOSifliOtaManager : NSObject

//这个SDK需要提前进行代理，不然在开始升级的时候，会出现蓝牙不可用的问题
//（ [SifliOTA][V1.2.18][SFOTAManager.swift bleCore(core:didUpdateState:)][290]蓝牙状态变化:BleCoreManagerState(rawValue: 5)
@property (nonatomic,assign) BOOL configDelegate;

+ (IDOSifliOtaManager *)shareInstance;


/// 开始OTA升级
/// - Parameters:
///   - files: OTA zip包解压后目录中文件
///   - deviceUUID: 设备UUID
- (void)startOTAWithFiles:(NSArray *)files deviceUUID:(NSString *)deviceUUID;

@end

NS_ASSUME_NONNULL_END
