//
//  IDOScManager.h
//  SifliOTADemo
//
//  Created by cyf on 2024/12/31.
//

#import <Foundation/Foundation.h>
typedef NS_ENUM(NSInteger, SIFLI_PLACEMENT_TYPE) {
    SIFLI_PLACEMENT_LEFT_TOP = 100,//时间左边顶部
    SIFLI_PLACEMENT_CENTER_TOP, //时间中心顶部
    SIFLI_PLACEMENT_RIGHT_TOP, //时间右边顶部
    SIFLI_PLACEMENT_LEFT_CENTER, //时间左边居中
    SIFLI_PLACEMENT_CENTER_CENTER, //时间中心居中
    SIFLI_PLACEMENT_RIGHT_CENTER, //时间右边居中
    SIFLI_PLACEMENT_LEFT_BOTTOM, //时间左边底部
    SIFLI_PLACEMENT_CENTER_BOTTOM, //时间中心底部
    SIFLI_PLACEMENT_RIGHT_BOTTOM, //时间右边底部
    SIFLI_PLACEMENT_MAX //全屏
};
NS_ASSUME_NONNULL_BEGIN

@interface IDOScManager : NSObject

/**
 * 制作思澈表盘文件
 * filePath:  传入素材路径, 制作成功后文件的路径为传入的filePath
 * @return 错误码，0成功 非0失败 -1: 没有控件 -2: json文件加载失败
 */

+ (int)getMakeSiFliWatchDialWithFilePath:(NSString *)filePath;

@end

NS_ASSUME_NONNULL_END
