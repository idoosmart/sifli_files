//
//  ViewController.m
//  SifliOTADemo
//
//  Created by cyf on 2024/12/26.
//

#import "ViewController.h"
#import "IDOSifliOtaManager.h"
#import "IDOSifliImageConvertor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //OTA 升级
    [IDOSifliOtaManager shareInstance].configDelegate = self;
    //  目标设备的identifier字符串。通过CBPeripheral.identifier.uuidString获取
    NSString *deviceUUID = @"xxxxxxx";
    NSArray * files = @[
        @"xxx/ctrl_packet.bin",
        @"xxx/outER_IROM1.bin",
        @"xxx/outER_IROM2.bin",
        @"xxx/outER_IROM3.bin",
        @"xxx/outroot.bin"
    ];
    [[IDOSifliOtaManager shareInstance] startOTAWithFiles:files deviceUUID:deviceUUID];
    
    //图片生成bin文件
    UIImage *previewImg = [UIImage imageNamed:@"previewImg"];
    NSData *imgData = UIImagePNGRepresentation(previewImg);
    NSArray *arr = @[imgData];
    // 图片生成bin文件的参数和安卓保持一致 颜色默认传 RGB888 (不能用rgb888 否则升级容易出现灰白图片)  其他传1
    NSData *binData  = [IDOSifliImageConvertor siFliEBinFromPngSequence:arr eColor:@"RGB888"  eType:0 binType:1 boardType:1];
   
}



@end
